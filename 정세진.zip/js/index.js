function menuOpen() {
    document.getElementById('mcontent').style.display = 'block';
}

function menuClose() {
    document.getElementById('mcontent').style.display = 'none';
}

function mediamenuON() {
    document.getElementById('mediamenu').style.display = 'block';
}

function mediamenuOFF() {
    document.getElementById('mediamenu').style.display = 'none';
}
